package iss.java.mail;

import java.io.IOException;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

/**
 * 实现IMailService接口中一系列的邮件收发方法
 * @author 刘燕龙  2015/11/17
 */
public class MyMailService2014302580196 implements IMailService{
	
	/**
	 * 邮件的主体message
	 */
	private MimeMessage message = null;
	
	/**
	 * 记录邮箱中新邮件的数目
	 */
	private int count = 0;
	
	/**
	 * 邮箱中邮件
	 */
	private Message[] messages = null;
	
	/**
	 * 用户名
	 */
	private static final String user = "15927367837";
	
	/**
	 * 密码
	 */
	private static final String passWord = "8742110";
	
	/**
	 * 初始化并连接邮件服务器
	 * @throws MessagingException 初始化或连接异常
	 */
	@Override
	public void connect() throws MessagingException {
		// TODO Auto-generated method stub
		//连接发送服务器
		Properties propsSend = new Properties();
		propsSend.setProperty("mail.host", "smtp.163.com");
		propsSend.setProperty("mail.transport.protocol", "smtp");
		propsSend.setProperty("mail.smtp.auth", "true");
		
		Session sessionSend = Session.getInstance(propsSend,new Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {  
                return new PasswordAuthentication(user, passWord);  
            } 
		});
		message = new MimeMessage(sessionSend);
		
		//连接接收服务器
		Properties propsReceive = new Properties();
		propsReceive.setProperty("mail.store.protocol", "imap");
		propsReceive.setProperty("mail.imap.host", "imap.163.com");
		
		Session sessionReceive=Session.getInstance(propsReceive,new Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {  
                return new PasswordAuthentication(user, passWord);  
            } 
		});
		Store store = sessionReceive.getStore("imap");
		store.connect( user, passWord);
		Folder folder = store.getFolder("INBOX");
		folder.open(Folder.READ_ONLY);
		count = folder.getNewMessageCount();
		messages = folder.getMessages();
	}

	/**
	 * 发送邮件
	 * @param recipient 收件人
	 * @param subject 邮件主题
	 * @param content 邮件内容
	 * 
	 * @throws MessagingException 发送邮件错误
	 */
	@Override
	public void send(String recipient, String subject, Object content)
			throws MessagingException {
		// TODO Auto-generated method stub
		message.setFrom(new InternetAddress("15927367837@163.com"));
		message.setRecipient(RecipientType.TO, new InternetAddress(recipient));
		message.setSubject(subject);
		message.setContent(content.toString(), "text/html;charset=utf-8");
		Transport.send(message);
	}
	
	/**
	 * 监听是否收到新邮件
	 * @throws MessagingException 发送邮件错误
	 */
	@Override
	public boolean listen() throws MessagingException {
		// TODO Auto-generated method stub
		if( count != 0)
			return true;
		else 
			return false;
	}

	/**
	 * @param sender 自动回复的发件人邮箱地址
	 * @param subject 自动回复的主题
	 * @return 自动回复的内容字符串
	 * @throws MessagingException 查询邮件异常
	 * @throws IOException 下载邮件异常
	 */
	@Override
	public String getReplyMessageContent(String sender, String subject)
			throws MessagingException, IOException {
		// TODO Auto-generated method stub
			String content ="没有收到回复！";
	        for(Message m:messages) {
	        	InternetAddress address[] = (InternetAddress[])m.getFrom();
	        	if(address[0].getAddress().equals(sender)&&m.getSubject().toString().equals(subject))
	        	{
	        		content = m.getContent().toString();
	        	}
	        }
		return content;
	}
}








